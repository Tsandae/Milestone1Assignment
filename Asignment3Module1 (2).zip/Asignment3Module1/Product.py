class Product:
    def __init__(self, product_name, product_id, price):
        self.product_name = product_name
        self.product_id = product_id
        self.price = price

    def update_price(self, new_price):
        self.price = new_price
        print(f"Price for {self.product_name} updated to {self.price}.")

    def suspend_product(self):
        print(f"Product {self.product_name} has been suspended.")
