class Policyholder:
    def __init__(self, name, policy_id):
        self.name = name
        self.policy_id = policy_id
        self.is_active = True 

    def suspend (self):
        self.is_active = False
        print( f"{self.name}has been suspended.")
    
    def display_details(self):
        return f"Policyholder: {self.name}, ID: {self.policy_id}"
