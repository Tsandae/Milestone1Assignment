class Payment:
    def __init__(self, policyholder, product):
        self.policyholder = policyholder
        self.product = product
        self.is_paid = False

    def process_payment(self, amount):
        if amount >= self.product.price:
            self.is_paid = True
            print(f"Payment of {amount} processed for {self.policyholder.name}.")
        else:
            print("Insufficient amount for payment.")

    def send_reminder(self):
        if not self.is_paid:
            print(f"Reminder: Payment is due for {self.policyholder.name}.")

    def apply_penalty(self):
        if not self.is_paid:
            print(f"Penalty applied for {self.policyholder.name}.")
